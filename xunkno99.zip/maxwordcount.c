#include <stdio.h>
#include "htab.h"

#include <stdio.h>

void print_pair(htab_pair_t *data) {
    //printf("%s\t%d\n", data->key, data->value);
}

void add(htab_t *hash_table, htab_key_t key) {
    htab_pair_t *pair = htab_lookup_add(hash_table, key);
    pair->value += 1;
}
int main(const int argc, const char *argv[]) {
    htab_t *hash_table = htab_init(100);

    FILE *file = fopen("ahoj.txt", "r");

    if (file == NULL) {
        printf("Chyba při otevírání souboru!\n");
        return 1;
    }

    char word[256];

    while (fscanf(file, "%s", word) == 1) {
        add(hash_table, word);
    }

    fclose(file);

    htab_for_each(hash_table, &print_pair);

    htab_free(hash_table);
}